package ca.gbc.comp3095.gbccomp3095assignment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GbcComp3095Assignment1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
