package ca.gbc.comp3095.lecture2.bootstrap;

import ca.gbc.comp3095.lecture2.domain.User;
import ca.gbc.comp3095.lecture2.repositories.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner {
    private final UserRepository userRepository;

    public BootStrapData(UserRepository userRepository) {
        this.userRepository = userRepository;
    }


    public void run(String... args) throws Exception {
        User user = new User("Thanh", "Duong", "mt.minhthanh@gmail.com", "$2a$10$kDqrEYVnPZjG6RKqmDEZXOluKfkc6Ppy35aIHUOnwix3.xOKJddbO", "mt.minhthanh@gmail.com");
        userRepository.save(user);
        System.out.println("Number of User " + userRepository.count());
    }



}