package ca.gbc.comp3095.lecture2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lecture2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
