package ca.gbc.comp3095.lecture2;

import ca.gbc.comp3095.lecture2.domain.User;
import ca.gbc.comp3095.lecture2.repositories.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class UserRepositoryTests {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TestEntityManager entiryManager;

    @Test
    public void testCreateUser(){
        User user = new User();
        user.setEmail("thanh@gmail.com");
        user.setPassword("thanh123");
        user.setFirstName("Thanh");
        user.setLastName("Duong");
        user.setAccount("thanh123");

        User savedUser = userRepository.save(user);

        User existUser = entiryManager.find(User.class, savedUser.getId());

        assertThat(existUser.getEmail()).isEqualTo(user.getEmail());
    }

    @Test
    public void testFindUserByEmail(){
        String account = "thanh";

        User userList = userRepository.findByEmail("mt.minhthanh11@gmail.com");


        assertThat(userList).isNotNull();
    }
}
